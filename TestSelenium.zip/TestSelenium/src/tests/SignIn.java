package tests;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.AccountCreation;
import pages.AuthenticationPage;
import pages.HomePage;
import utils.DriverSetup;

@Test
public class SignIn extends DriverSetup {

    HomePage homePage;
    AuthenticationPage authenticationPage;
    AccountCreation accountCreation;

    @BeforeTest
    public void setUp() {
        initPage();
    }

    @Test
    public void signInTest() {
        homePage = new HomePage(driver);
        authenticationPage = new AuthenticationPage(driver);

        //Go to authentication page
        homePage.signInClick();

        //Fill Address, password fields and click on Sign in
        authenticationPage.emailAddressTextField.sendKeys("myEmail@email.com");
        authenticationPage.passwordTextField.sendKeys("password123");
        authenticationPage.signInClick();

        //Assertion over Alert message error type 1
        Assert.assertTrue(authenticationPage.alertMessageError1.isDisplayed());
    }

    @Test
    public void createAccountTest() {
        homePage = new HomePage(driver);
        authenticationPage = new AuthenticationPage(driver);
        accountCreation = new AccountCreation(driver);

        //Go to authentication page
        homePage.signInClick();

        //Fill Address and click on Create Account
        authenticationPage.emailAddressCreateAccTextField.sendKeys("myEmail777@email.com");
        authenticationPage.createAccClick();

        //Assertion over new page: Account creation
        Assert.assertTrue(accountCreation.divForm.isDisplayed());
    }

    @AfterClass
    public void tearDown() {
        driver.close();
    }

}
