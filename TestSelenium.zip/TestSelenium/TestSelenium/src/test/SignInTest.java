package test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.openqa.selenium.WebDriverException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.AccountCreation;
import pages.AuthenticationPage;
import pages.HomePage;
import pages.MyAccountPage;
import pages.WomenPage;
import utils.DriverSetup;

public class SignInTest extends DriverSetup {

	HomePage homePage;
	AuthenticationPage authenticationPage;
	AccountCreation accountCreation;
	MyAccountPage myAccountPage;
	WomenPage womenPage;

	@BeforeTest
	@Parameters("browser") 
	public void setUp(String browser) {
		try {
		if(browser.equalsIgnoreCase("Chrome")) {
			initChromePage();
		}
		else if(browser.equalsIgnoreCase("Firefox")) {
			initFirefoxPage();	
		}
		}
		catch (WebDriverException e)
		{

			System.out.println("Browser not found" +e.getMessage());

		}
	}

	/**
	 * @return Object[][] where first column contains 'email' and second column
	 *         contains 'password'
	 * @throws IOException
	 */
	@SuppressWarnings("resource")
	@DataProvider(name = "searchCounterProvider")
	public Iterator<Object[]> searchCounterprovider() throws InterruptedException, IOException {

		String[] data = null;
		String csvFile = "TestSelenium\\SearchTestData.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		List<Object[]> testCases = new ArrayList<>();

		// this loop is pseudo code
		br = new BufferedReader(new FileReader(csvFile));
		while ((line = br.readLine()) != null) {
			// use comma as separator
			data = line.split(cvsSplitBy);
			System.out.println("data" + data);
			testCases.add(data);
		}

		return testCases.iterator();
	}

	@SuppressWarnings("resource")
	@DataProvider(name = "InvalidAccountProvider")
	public Iterator<Object[]> getInvalidAccountDataProvider() throws InterruptedException, IOException {

		String[] data = null;
		String csvFile = "TestSelenium\\InvalidAcountTestData.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		List<Object[]> testCases = new ArrayList<>();

		// this loop is pseudo code
		br = new BufferedReader(new FileReader(csvFile));
		while ((line = br.readLine()) != null) {
			// use comma as separator
			data = line.split(cvsSplitBy);
			testCases.add(data);
		}

		return testCases.iterator();
	}

	@SuppressWarnings("resource")
	@DataProvider(name = "ValidAccountProvider")
	public Iterator<Object[]> getValidAccountDataProvider() throws InterruptedException, IOException {

		String[] data = null;
		String csvFile = "TestSelenium\\ValidAcountTestData.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		List<Object[]> testCases = new ArrayList<>();

		// this loop is pseudo code
		br = new BufferedReader(new FileReader(csvFile));
		while ((line = br.readLine()) != null) {
			// use comma as separator
			data = line.split(cvsSplitBy);
			testCases.add(data);
		}

		return testCases.iterator();
	}

	@SuppressWarnings("resource")
	@DataProvider(name = "manufacturerDataProvider")
	public Iterator<Object[]> getManufacturerDataProvider() throws InterruptedException, IOException {

		String[] data = null;
		String csvFile = "TestSelenium\\ManufacturerTestData.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		List<Object[]> testCases = new ArrayList<>();

		// this loop is pseudo code
		br = new BufferedReader(new FileReader(csvFile));
		while ((line = br.readLine()) != null) {
			// use comma as separator
			data = line.split(cvsSplitBy);
			testCases.add(data);
		}

		return testCases.iterator();
	}

	
	// Fuctional Area: Sign In
	// Action: Login to the account with validcredentials
	// Verification: Check if Log off menu appears on top
	// 2

	@Test(priority = 2, dataProvider = "ValidAccountProvider")
	public void signInTest(String email, String password) throws InterruptedException {
		homePage = new HomePage(driver);
		authenticationPage = new AuthenticationPage(driver);
		myAccountPage = new MyAccountPage(driver);
		// Go to authentication page
		homePage.signInClick();
		System.out.println("Welcome ->" + email + " Your pass ->" + password);
		// Fill Address, password fields and click on Sign in
		authenticationPage.emailAddressTextField.sendKeys(email);
		authenticationPage.passwordTextField.sendKeys(password);
		authenticationPage.signInClick(); // Assertion over sign off button
		Assert.assertTrue(myAccountPage.signOffButton.isDisplayed());

	}

	// Fuctional Area: LogOff
	// Action: Click on Log Offbutton
	// Verification: Verify the Log Offmessage
	// 2

	@Test(priority = 3, dataProvider = "ValidAccountProvider")
	public void signOffTest(String email, String password) throws InterruptedException {
		
		/// Thread.sleep(2000);
		myAccountPage.signOffClick(); // Assertion over sign off button
		Assert.assertTrue(homePage.authenticationLabel.isDisplayed());

	}

	// Functional Area: search // Action: Type a relevant word on search field //
	// Verification: Verify whether the number of items that appears is as per //
	// expected value // 4

	@Test(priority = 1, dataProvider = "searchCounterProvider")
	public void searchTest(String search, String countDataSearch) {

		System.out.println(countDataSearch);
		homePage = new HomePage(driver);
		// Fill search field
		homePage.searchTextField.sendKeys(search);
		// click on search button
		homePage.searchButtonClick();

		String searchResult = homePage.searchResult.getText();
		String countSearch = searchResult.substring(0, 1);
		System.out.println(countSearch + "data:" + countDataSearch);
		// Thread.sleep(2000);
		// Assertion over the search result
		Assert.assertEquals(countSearch, countDataSearch);

	}

	// Functional Area: Sign In
	// Action: Try Login with invalidcredential
	// Handle the popped-up alert. Do the same for post code which is
	// lessthan4character
	// Verification: Success if alert messageappears, failure if it does not come
	// 3
	@Test(priority = 4, dataProvider = "InvalidAccountProvider")
	public void signInInvalidcredentialTest(String email, String password) {
		System.out.println("Welcome ->" + email + " Your pass ->" + password);
		homePage = new HomePage(driver);
		authenticationPage = new AuthenticationPage(driver);

		// Go to authentication page
		homePage.signInClick();
		System.out.println("Welcome ->" + email + " Your pass ->" + password);
		// Fill Address, password fields and click on Sign in
		authenticationPage.emailAddressTextField.sendKeys(email);
		authenticationPage.passwordTextField.sendKeys(password);
		authenticationPage.signInClick();

		// Assertion over Alert message error type 1
		Assert.assertTrue(authenticationPage.alertMessageError1.isDisplayed());
	}

	@Test(priority = 5, dataProvider = "manufacturerDataProvider")
	public void manufacterFilterTest(String manufacturer, String productCounter) {

		homePage = new HomePage(driver);
		womenPage = new WomenPage(driver);
		// click on women button
		homePage.womenButtonClick();

		womenPage = new WomenPage(driver);
		womenPage.checkManufactorer(manufacturer);

		if (womenPage.producContainer.isDisplayed()) {
			String filterProductResult = womenPage.counterProducts.getText();
			Assert.assertTrue(filterProductResult.contains(productCounter));
		} else {
			Assert.assertTrue(womenPage.producContainer.isDisplayed(), "Container not found");
		}

	}

	@AfterClass
	public void tearDown() throws InterruptedException {
		Thread.sleep(10);
		driver.close();
	}

}
