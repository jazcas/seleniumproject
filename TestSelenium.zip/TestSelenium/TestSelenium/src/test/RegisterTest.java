package test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.*;

import pages.AccountCreation;
import pages.AuthenticationPage;
import pages.HomePage;

import utils.DriverSetup;

public class RegisterTest extends DriverSetup {

	HomePage homePage;
	AuthenticationPage authenticationPage;
	AccountCreation accountCreation;
	
	@Parameters("browser") 
	public void setUp(String browser) {
		if(browser.equalsIgnoreCase("Chrome")) {
			initChromePage();
		}
		else if(browser.equalsIgnoreCase("Firefox")) {
			initFirefoxPage();	
		}
	}

	
	
	@SuppressWarnings("resource")
	@DataProvider(name = "newAccountProvider")
    public Iterator<Object []> getRegAccountTestData() throws InterruptedException, IOException {
    
    	String[] data= null;
        String csvFile = "TestSelenium\\RegAccountTestData.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        List<Object []> testCases = new ArrayList<>();
     

        //this loop is pseudo code
        br = new BufferedReader(new FileReader(csvFile));
        while ((line = br.readLine()) != null) {
            // use comma as separator
            data= line.split(cvsSplitBy);
            System.out.println("data" + data );
            testCases.add(data);
        }

        return testCases.iterator();
    }

	@BeforeTest
	public void setUp() {
		initChromePage();
	}

	// Functional Area: Account
	// Action: Create a new account with EthnicStore
	// Verification: Success if you get a verifying message
	// 3
	
	  @Test(priority = 2, dataProvider = "newAccountProvider") 
	  public void  createAccountTest(String email, String title, String firstName, String
	  lastName, String password, String days, String months, String years, String
	  newsletter, String offers, String company, String mainAddress, String
	  secondAddress, String city, String state, String zip, String country, String
	  homePhone, String adInfox, String mobilePhone, String aliasAddress) {
	  
	  homePage = new HomePage(driver); 
	  authenticationPage = new  AuthenticationPage(driver); 
	  accountCreation = new AccountCreation(driver);
	  String creationSuccessText =  "Welcome to your account. Here you can manage all of your personal information and orders"
	  ;
	  
	  // Go to authentication page 
	  homePage.signInClick();
	  
	  // Fill Address and click on Create Account
	  authenticationPage.emailAddressCreateAccTextField.sendKeys(email);
	  authenticationPage.createAccClick(); if
	  (accountCreation.divForm.isDisplayed()) { accountCreation.checkTitle(title);
	  accountCreation.firstName.sendKeys("firstname");
	  accountCreation.lastName.sendKeys("lastName");
	  accountCreation.password.sendKeys("password");
	  
	  accountCreation.selectBirthdayDate(days, months, years);
	  accountCreation.checkNewsletter(newsletter);
	  accountCreation.checkSpecialOffers(offers);
	  
	  accountCreation.enterCompany(company);
	  accountCreation.enterMainAddress(mainAddress);
	  accountCreation.enterSecondAddress(secondAddress);
	  accountCreation.enterCity(city); accountCreation.selectState(state);
	  accountCreation.enterZip(zip); accountCreation.selectCountry(country);
	  accountCreation.enterAdditionalInfo(adInfox);
	  accountCreation.enterHomePhone(homePhone);
	  accountCreation.enterMobilePhone(mobilePhone);
	  accountCreation.enterAliasAddres(aliasAddress);
	  accountCreation.clickToRegister(); 
	  
	  // Assertion over new page: Account creation
	  Assert.assertTrue(driver.getPageSource().contains(creationSuccessText)); }
	  else { Assert.assertTrue(accountCreation.divForm.isDisplayed(),
	  "Form not found"); }
	  
	  }
	 

	
	// Functional Area: Account
	// Action: Leave out the �Country� field unselected.
	// Handle the popped-up alert. Do the same for post code which is
	// lessthan4character
	// Verification: Success if alert messageappears, failure if it does not come
	// 4
	@Test(priority = 1, dataProvider = "newAccountProvider")
	public void RNwAccountCountryAlertMessageTest(String email, String title, String firstName, String lastName, String password,
			String days, String months, String years, String newsletter, String offers, String company,
			String mainAddress, String secondAddress, String city, String state, String zip, String country,
			String homePhone, String adInfox, String mobilePhone, String aliasAddress) {
		
		homePage = new HomePage(driver);
		authenticationPage = new AuthenticationPage(driver);
		accountCreation = new AccountCreation(driver);
		String zipCodeErrorMsg = "The Zip/Postal code you've entered is invalid. It must follow this format: 00000";
		
		// Go to authentication page
		homePage.signInClick();

		// Fill Address and click on Create Account
		authenticationPage.emailAddressCreateAccTextField.sendKeys(email);
		authenticationPage.createAccClick();
		if (accountCreation.divForm.isDisplayed()) {
			accountCreation.checkTitle(title);
			accountCreation.firstName.sendKeys("firstname");
			accountCreation.lastName.sendKeys("lastName");
			accountCreation.password.sendKeys("password");

			accountCreation.selectBirthdayDate(days, months, years);
			accountCreation.checkNewsletter(newsletter);
			accountCreation.checkSpecialOffers(offers);

			accountCreation.enterCompany(company);
			accountCreation.enterMainAddress(mainAddress);
			accountCreation.enterSecondAddress(secondAddress);
			accountCreation.enterCity(city);
			accountCreation.selectState(state);
			//accountCreation.enterZip(zip);
			accountCreation.selectCountry(country);
			accountCreation.enterAdditionalInfo(adInfox);
			accountCreation.enterHomePhone(homePhone);
			accountCreation.enterMobilePhone(mobilePhone);
			accountCreation.enterAliasAddres(aliasAddress);
			accountCreation.clickToRegister();
			
			Assert.assertTrue(driver.getPageSource().contains(zipCodeErrorMsg));

	}
		else {
			Assert.assertTrue(accountCreation.divForm.isDisplayed(), "Form not found");
			}
		}

	@AfterClass
	public void tearDown() throws InterruptedException {
		Thread.sleep(10);
		driver.close();
	}
}
