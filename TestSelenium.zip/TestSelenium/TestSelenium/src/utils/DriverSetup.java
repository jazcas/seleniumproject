package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

/**
 * Base class for Driver handle actions
 */
public class DriverSetup {
	
	protected WebDriver driver;
	protected String URL = "http://automationpractice.com/index.php";
	
	protected void initChromePage() {
		System.setProperty("webdriver.chrome.driver", "TestSelenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(URL);
		driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        
	}

	protected void initFirefoxPage() {
		System.setProperty("webdriver.gecko.driver", "TestSelenium\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get(URL);
		driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        
        
	}
}
