 package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import utils.DriverSetup;

public class AuthenticationPage extends DriverSetup {

    @FindBy(how = How.ID, using = "email")
    public WebElement emailAddressTextField;

    @FindBy(how = How.ID, using = "passwd")
    public WebElement passwordTextField;

    @FindBy(how = How.ID, using = "SubmitLogin")
    public WebElement signInButton;

    @FindBy(how = How.ID, using = "email_create")
    public WebElement emailAddressCreateAccTextField;

    @FindBy(how = How.ID, using = "SubmitCreate")
    public WebElement createAccountButton;

    @FindBy(how = How.XPATH, using = "//*[@id=\"center_column\"]/div[1]")
    public WebElement alertMessageError1;

    public AuthenticationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void signInClick() {
        signInButton.click();
    }

    public void createAccClick() {
        createAccountButton.click();
    }
}
