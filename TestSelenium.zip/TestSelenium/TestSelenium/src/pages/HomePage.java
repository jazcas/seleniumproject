package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import utils.DriverSetup;

public class HomePage extends DriverSetup {

    @FindBy(how = How.CLASS_NAME, using = "login")
    public WebElement signIn;
    
    @FindBy(id = "search_query_top")
    public WebElement searchTextField;
    
   
    @FindBy(how = How.CSS, using = "#searchbox button[type='submit']")
    public WebElement searchButton;
    
    @FindBy(how = How.XPATH, using = "//span[@class='heading-counter']")
    public WebElement searchResult;
    
    @FindBy(how = How.XPATH, using = "//a[@class='sf-with-ul'][contains(text(),'Women')]")
    public WebElement womenButton;
    
    @FindBy(how = How.CLASS_NAME, using = "page-heading")
    public WebElement authenticationLabel;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void signInClick() {
        signIn.click();
    }
    
    public void searchButtonClick() {
    	searchButton.click();
    }
    
    public void womenButtonClick() {
    	womenButton.click();
    }
    
}
