package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utils.DriverSetup;

public class WomenPage  extends DriverSetup { 
	
	public WomenPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
	 @FindBy(id = "layered_manufacturer_1")
	    public WebElement manufactorerCheckBox;
	 
	 @FindBy(xpath = "//li[@class='ajax_block_product col-xs-12 col-sm-6 col-md-4 first-in-line first-item-of-tablet-line first-item-of-mobile-line']//div[@class='product-image-container']")
	    public WebElement producContainer;
	 
	 @FindBy(xpath = "//div[@class='bottom-pagination-content clearfix']//div[@class='product-count'][contains(text(),'Showing 1 - 7 of 7 items')]")
	    public WebElement counterProducts;
	 
	 public void checkManufactorer(String manufactorer){
	        if(manufactorer.equals("y")){
	        	manufactorerCheckBox.click();
	        }
	    }

}
